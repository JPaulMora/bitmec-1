library patient_components;

export 'patient_card.dart';
export 'patient_list_view.dart';

export 'patient_detail_general_view.dart';
export 'patient_detail_medical_history_view.dart';
export 'patient_detail_family_history_view.dart';
export 'patient_detail_habits_views.dart';
export 'patient_detail_dependents_view.dart';
